package appmoviles.com.reglasandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    TextView console;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        console = findViewById(R.id.console);

        //1. Usar networking solo en hilos worker
        new Thread(
                ()->{
                    try {
                        URL url = new URL("https://www.google.com");
                        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
                        InputStream is = connection.getInputStream();

                        BufferedReader breader = new BufferedReader(new InputStreamReader(is));

                        String line;
                        while( (line = breader.readLine()) != null ){
                            Log.e(">>>",line);

                            String finalLine = line;
                            runOnUiThread(
                                    ()->{
                                        console.append(finalLine);
                                    }
                            );


                        }
                        breader.close();

                        //Solo el hilo GUI puede controlar o cambiar la vista



                    }catch (IOException ex){
                        ex.printStackTrace();
                    }
                }
        ).start();




    }
}
