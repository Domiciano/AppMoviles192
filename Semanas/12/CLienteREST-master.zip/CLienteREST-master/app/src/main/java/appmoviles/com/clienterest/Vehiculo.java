package appmoviles.com.clienterest;

public class Vehiculo {

    public String marca;
    public int modelo;
    public String propietario;

}
