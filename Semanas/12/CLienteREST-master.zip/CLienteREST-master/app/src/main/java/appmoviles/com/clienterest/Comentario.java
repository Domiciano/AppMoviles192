package appmoviles.com.clienterest;

public class Comentario {

    public String de;
    public String para;
    public String comentario;


    public Comentario(){}

    public Comentario(String de, String para, String comentario) {
        this.de = de;
        this.para = para;
        this.comentario = comentario;
    }
}
