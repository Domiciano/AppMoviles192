package appmoviles.com.clienterest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView salida;
    private EditText para;
    private EditText comentario;
    private Button enviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        salida = findViewById(R.id.salida);
        para = findViewById(R.id.para);
        comentario = findViewById(R.id.comentario);
        enviar = findViewById(R.id.enviar);


        enviar.setOnClickListener(view -> {
            String paraStr = para.getText().toString();
            String comentarioStr = comentario.getText().toString();
            Comentario comentario = new Comentario("Domiciano", paraStr, comentarioStr);
            Gson gson = new Gson();
            String json = gson.toJson(comentario);

            new Thread(
                    ()->{
                        HTTPSWebUtilDomi util = new HTTPSWebUtilDomi();
                        try {
                            util.POSTrequest("https://instalacion-bc3ad.firebaseio.com/comentarios.json", json);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
            ).start();

        });


        new Thread(
                () -> {
                    try {
                        HTTPSWebUtilDomi util = new HTTPSWebUtilDomi();
                        String json = util.GETrequest("https://instalacion-bc3ad.firebaseio.com/vehiculos.json");
                        Log.e(">>>",json);

                        Gson g = new Gson();
                        Type tipo = new TypeToken< ArrayList<Vehiculo> >(){}.getType();

                        //Vehiculo[] vehiculos = g.fromJson(json, Vehiculo[].class);
                        ArrayList<Vehiculo> vehiculos = g.fromJson(json, tipo);
                       runOnUiThread( ()-> salida.setText( ""+vehiculos.size())  );
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        ).start();


    }
}

/*
                ()->{

                 }

                 new Runnable{
                    @Override
                    public void run(){

                    }
                }

*/
