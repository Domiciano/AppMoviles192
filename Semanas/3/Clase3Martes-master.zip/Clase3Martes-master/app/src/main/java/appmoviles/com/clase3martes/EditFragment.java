package appmoviles.com.clase3martes;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class EditFragment extends Fragment {

    private EditText editDescripcion;
    private Button cambiarBtn;

    public EditFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_edit, container, false);
        editDescripcion = view.findViewById(R.id.edit_descripcion);
        cambiarBtn = view.findViewById(R.id.cambiar_btn);

        cambiarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener!=null) listener.onDescription(  editDescripcion.getText().toString()  );

                Log.e("EditFragment", "Cambio de fragment");
                ((ProfileActivity) getActivity()).showProfileFragment();

            }
        });


        return view;
    }


    //PATRON OBSERVER
    public interface OnDescriptionChanged{
        void onDescription(String descripcion);
    }
    private OnDescriptionChanged listener;

    public void setListener(OnDescriptionChanged listener){
        this.listener = listener;
    }


}
