package appmoviles.com.clase3martes;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class ProfileActivity extends AppCompatActivity {

    private LinearLayout fragmentContainer;
    private Button profileBtn, editBtn, optionsBtn;


    private ProfileFragment profileFragment;
    private EditFragment editFragment;
    private OptionsFragment optionsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        fragmentContainer = findViewById(R.id.fragment_container);
        profileBtn = findViewById(R.id.profile_btn);
        editBtn = findViewById(R.id.edit_btn);
        optionsBtn = findViewById(R.id.options_btn);

        profileBtn.setOnClickListener(menuAction);
        editBtn.setOnClickListener(menuAction);
        optionsBtn.setOnClickListener(menuAction);

        profileFragment = new ProfileFragment();
        editFragment = new EditFragment();
        optionsFragment = new OptionsFragment();

        editFragment.setListener(profileFragment);
    }

    View.OnClickListener menuAction = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction ft = manager.beginTransaction();

            if(v.equals(profileBtn)) ft.replace(R.id.fragment_container, profileFragment);
            else if(v.equals(editBtn)) ft.replace(R.id.fragment_container, editFragment);
            else if(v.equals(optionsBtn)) ft.replace(R.id.fragment_container, optionsFragment);

            ft.commit();
        }
    };

    public void showProfileFragment(){
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        ft.replace(R.id.fragment_container, profileFragment);
        ft.commit();
    }

}
