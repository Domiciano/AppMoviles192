package appmoviles.com.clase3martes;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment implements EditFragment.OnDescriptionChanged {

    private TextView profileDescripcion;
    private String descripcion;

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        profileDescripcion = view.findViewById(R.id.profile_descripcion);
        profileDescripcion.setText(descripcion);
        return view;
    }



    @Override
    public void onDescription(String descripcion) {
        this.descripcion = descripcion;
    }
}
