package appmoviles.com.solucionejercicioclase3;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment implements EditFragment.OnDescriptionChanged, EditFragmentDialog.OnDescriptionChanged {

    TextView profileDescripcion;
    private String descripcion;
    Button hotButton;

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        profileDescripcion = v.findViewById(R.id.profile_descripcion);
        profileDescripcion.setText(descripcion);
        hotButton = v.findViewById(R.id.hot_button);
        hotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager = getActivity().getSupportFragmentManager();
                final EditFragmentDialog fragment = new EditFragmentDialog();
                fragment.setListener(new EditFragmentDialog.OnDescriptionChanged() {
                    @Override
                    public void onDescriptionChanged(String descripcion) {
                        profileDescripcion.setText(descripcion);
                        fragment.dismiss();
                    }
                });
                fragment.show(manager,"alfa");
            }
        });
        return v;
    }

    @Override
    public void onDescriptionChanged(String descripcion) {
        this.descripcion = descripcion;

    }
}
