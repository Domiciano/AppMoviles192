package appmoviles.com.solucionejercicioclase3;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class AlterProfileActivity extends AppCompatActivity {

    private ProfileFragment fragmentProfile;
    private OptionsFragment fragmentOptions;
    private EditFragment fragmentEdit;
    private Button optionProfileTv,optionEditTv,optionOptionsTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alter_profile);

        fragmentProfile = new ProfileFragment();
        fragmentOptions = new OptionsFragment();
        fragmentEdit = new EditFragment();
        fragmentEdit.setListener(fragmentProfile);


        optionProfileTv = findViewById(R.id.option_profile_tv);
        optionEditTv = findViewById(R.id.option_edit_tv);
        optionOptionsTv = findViewById(R.id.option_options_tv);

        optionProfileTv.setOnClickListener(menuAction);
        optionEditTv.setOnClickListener(menuAction);
        optionOptionsTv.setOnClickListener(menuAction);
    }

    View.OnClickListener menuAction = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction ft = manager.beginTransaction();
            if(v.equals(optionProfileTv)){
                ft.replace(R.id.fragment_container, fragmentProfile);
            }else if(v.equals(optionEditTv)){
                ft.replace(R.id.fragment_container, fragmentEdit);
            }else if(v.equals(optionOptionsTv)){
                ft.replace(R.id.fragment_container, fragmentOptions);
            }
            ft.commit();
        }
    };
}
