package appmoviles.com.preclase13.model.remote;

public class DatabaseConstants {
    public static final String EMBEDDING = "completeAlbums";
    public static final String USERS = "users";
    public static final String PHOTOS = "photos";
    public static final String ALBUMS = "albums";
}
