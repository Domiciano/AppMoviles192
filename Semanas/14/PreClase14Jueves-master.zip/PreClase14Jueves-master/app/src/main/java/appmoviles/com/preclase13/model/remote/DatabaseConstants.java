package appmoviles.com.preclase13.model.remote;

public class DatabaseConstants {
    public static final String EMBEDDING = "albumEmbedding";
    public static final String USERS = "usuarios";
    public static final String PHOTOS = "fotos";
    public static final String ALBUMS = "albums";
}
