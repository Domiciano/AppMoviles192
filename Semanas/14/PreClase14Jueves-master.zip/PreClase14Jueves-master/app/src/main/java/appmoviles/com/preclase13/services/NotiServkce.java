package appmoviles.com.preclase13.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import appmoviles.com.preclase13.model.entity.Comment;
import appmoviles.com.preclase13.util.NotificationUtils;

public class NotiServkce extends Service {

    FirebaseDatabase db;
    FirebaseAuth auth;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        db = FirebaseDatabase.getInstance();
        auth = FirebaseAuth.getInstance();
        db.getReference().child("notificaciones")
                .child(auth.getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int i = 0;
                        for(DataSnapshot comentario : dataSnapshot.getChildren()){
                            Comment c = comentario.getValue(Comment.class);
                            NotificationUtils.createNotification(
                                    i++,
                                    "Nuevo comentario",
                                    c.getText()
                            );
                            db.getReference().child("notificaciones")
                                    .child(auth.getCurrentUser().getUid())
                                    .child(c.getUid())
                                    .setValue(null);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
       return null;
    }
}
