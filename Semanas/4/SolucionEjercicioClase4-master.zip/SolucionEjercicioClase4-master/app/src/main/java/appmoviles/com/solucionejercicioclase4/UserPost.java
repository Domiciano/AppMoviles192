package appmoviles.com.solucionejercicioclase4;

import java.util.Date;

public class UserPost {
    private String uuid;
    private String description;
    private int profilePhoto;
    private int views;
    private Date date;
    private boolean liked;

    public UserPost(String uuid, String description, int profilePhoto, int views, Date date, boolean liked) {
        this.uuid = uuid;
        this.description = description;
        this.profilePhoto = profilePhoto;
        this.views = views;
        this.date = date;
        this.liked = liked;
    }

    public UserPost() {
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getProfilePhoto() {
        return profilePhoto;
    }

    public void setProfilePhoto(int profilePhoto) {
        this.profilePhoto = profilePhoto;
    }

    public int getViews() {
        return views;
    }

    public void setViews(int views) {
        this.views = views;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isLiked() {
        return liked;
    }

    public void setLiked(boolean liked) {
        this.liked = liked;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
}
