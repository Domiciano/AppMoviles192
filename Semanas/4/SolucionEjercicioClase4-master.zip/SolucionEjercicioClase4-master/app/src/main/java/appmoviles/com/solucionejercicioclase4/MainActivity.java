package appmoviles.com.solucionejercicioclase4;

import android.Manifest;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.Calendar;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private ListView postList;
    private FeedAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 11);


        postList = findViewById(R.id.post_list);
        adapter = new FeedAdapter();
        postList.setAdapter(adapter);

        adapter.addElement(new UserPost(UUID.randomUUID().toString(),
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat",
                R.drawable.photo1,
                (int)(1000*Math.random()),
                Calendar.getInstance().getTime(), false));

        adapter.addElement(new UserPost(UUID.randomUUID().toString(),
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat",
                R.drawable.photo2,
                (int)(1000*Math.random()),
                Calendar.getInstance().getTime(), false));

        adapter.addElement(new UserPost(UUID.randomUUID().toString(),
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat",
                R.drawable.photo3,
                (int)(1000*Math.random()),
                Calendar.getInstance().getTime(), false));

        adapter.addElement(new UserPost(UUID.randomUUID().toString(),
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat",
                R.drawable.photo4,
                (int)(1000*Math.random()),
                Calendar.getInstance().getTime(), false));

        adapter.addElement(new UserPost(UUID.randomUUID().toString(),
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat",
                R.drawable.photo5,
                (int)(1000*Math.random()),
                Calendar.getInstance().getTime(), false));





    }
}
