package appmoviles.com.solucionejercicioclase4;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class FeedAdapter extends BaseAdapter {

    private ArrayList<UserPost> objects;

    public FeedAdapter(){
        objects = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.row, null, false);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        final UserPost data = objects.get(position);

        ImageView rowPhoto = v.findViewById(R.id.row_photo);
        TextView rowDate  = v.findViewById(R.id.row_date);
        Button rowDelete = v.findViewById(R.id.row_delete);
        TextView rowDescription = v.findViewById(R.id.row_description);
        Button rowLike = v.findViewById(R.id.row_like);
        TextView rowViews = v.findViewById(R.id.row_views);

        rowPhoto.setImageResource(data.getProfilePhoto());
        rowDate.setText("Fecha: " + sdf.format(data.getDate()));
        rowDescription.setText(data.getDescription());
        rowViews.setText("Views: "+data.getViews());
        if(data.isLiked()) rowLike.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#4169E1")));
        else rowLike.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#DDDDDD")));

        rowLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data.setLiked(!data.isLiked());
                notifyDataSetChanged();
            }
        });

        rowDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(parent.getContext())
                        .setTitle("Eliminar publicación")
                        .setMessage("¿Está seguro que desea eliminar la publicación?")
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                                dialog.dismiss();
                            }
                        })
                        .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                objects.remove(data);
                                notifyDataSetChanged();
                            }
                        });
                        builder.show();
            }
        });

        return v;
    }

    public void addElement(UserPost post){
        objects.add(post);
        notifyDataSetChanged();
    }
}
