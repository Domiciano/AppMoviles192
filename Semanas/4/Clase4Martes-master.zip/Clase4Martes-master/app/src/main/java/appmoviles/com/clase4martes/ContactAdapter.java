package appmoviles.com.clase4martes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class ContactAdapter extends BaseAdapter {

    private ArrayList<Contact> contacts;

    public ContactAdapter(){
        contacts = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return contacts.size();
    }

    @Override
    public Object getItem(int position) {
        return contacts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    //Se encarga de un objeto visible a la vez
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.row, null );

        TextView rowName = view.findViewById(R.id.row_name);
        TextView rowTel = view.findViewById(R.id.row_tel);
        Button rowCall = view.findViewById(R.id.row_call);
        Button rowDelete = view.findViewById(R.id.row_delete);

        final Contact data = contacts.get(position);

        //rowCall TAREA: ACTION_CALL

        rowDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contacts.remove(data);
                notifyDataSetChanged();
            }
        });

        rowName.setText( data.getNombre() );
        rowTel.setText( data.getTelefono() );

        return view;
    }

    public void addContact(Contact c){
        contacts.add(c);
        notifyDataSetChanged();
    }

}
