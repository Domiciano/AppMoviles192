package appmoviles.com.clase4martes;

import android.Manifest;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private EditText nameEt;
    private EditText telEt;
    private Button addContactBtn;
    private ListView contactList;
    private ContactAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE, Manifest.permission.INTERNET}, 11);

        nameEt = findViewById(R.id.name_et);
        telEt = findViewById(R.id.tel_et);
        addContactBtn = findViewById(R.id.add_contact_btn);
        contactList = findViewById(R.id.contact_list);
        adapter = new ContactAdapter();
        contactList.setAdapter(adapter);

        addContactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Contact c = new Contact(nameEt.getText().toString(), telEt.getText().toString());
                adapter.addContact(c);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == 11){

        }
    }
}
