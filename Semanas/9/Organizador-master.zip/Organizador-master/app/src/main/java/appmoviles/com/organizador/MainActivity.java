package appmoviles.com.organizador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.UUID;

import appmoviles.com.organizador.app.OrganizadorApp;
import appmoviles.com.organizador.model.data.CRUDTasklist;
import appmoviles.com.organizador.model.driver.DBDriver;
import appmoviles.com.organizador.model.entity.Tasklist;

public class MainActivity extends AppCompatActivity {

    ListView LVTasklist;
    ArrayAdapter<Tasklist> adapter;
    ArrayList<Tasklist> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        LVTasklist = findViewById(R.id.LVTasklist);
        LVTasklist.setAdapter(adapter);


        /*
        CRUDTasklist.insertTasklist(  new Tasklist(UUID.randomUUID().toString(),
                "AppMoviles", Calendar.getInstance().getTime()));

        CRUDTasklist.insertTasklist(  new Tasklist(UUID.randomUUID().toString(),
                "Integrador", Calendar.getInstance().getTime()));

        CRUDTasklist.insertTasklist(  new Tasklist(UUID.randomUUID().toString(),
                "APO1", Calendar.getInstance().getTime()));

        */

        ArrayList<Tasklist> group = CRUDTasklist.getAllTasklist();
        for(int i=0 ; i<group.size() ; i++){
            list.add(group.get(i));
        }
        adapter.notifyDataSetChanged();



        LVTasklist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
                Toast.makeText(OrganizadorApp.getContext(), list.get(pos).getName(), Toast.LENGTH_SHORT).show();
            }
        });



    }
}
