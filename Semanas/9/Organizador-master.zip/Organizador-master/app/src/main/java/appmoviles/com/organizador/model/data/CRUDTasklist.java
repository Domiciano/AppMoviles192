package appmoviles.com.organizador.model.data;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Date;

import appmoviles.com.organizador.app.OrganizadorApp;
import appmoviles.com.organizador.model.driver.DBDriver;
import appmoviles.com.organizador.model.entity.Tasklist;

public class CRUDTasklist {


    public static void insertTasklist(Tasklist tasklist){
        DBDriver driver = DBDriver.getInstance(OrganizadorApp.getContext());
        SQLiteDatabase db = driver.getWritableDatabase();

        String sql = "INSERT INTO $TABLE($ID,$NAME,$DATE) VALUES('$VID','$VNAME', $VDATE)";
        sql = sql
                .replace("$TABLE", DBDriver.TABLE_TASKLIST)
                .replace("$ID", DBDriver.TASKLIST_ID)
                .replace("$NAME", DBDriver.TASKLIST_NAME)
                .replace("$DATE", DBDriver.TASKLIST_DATE)
                .replace("$VID", tasklist.getId())
                .replace("$VNAME", tasklist.getName())
                .replace("$VDATE", ""+tasklist.getDate().getTime());


        db.execSQL(sql);
        db.close();
    }


    public static ArrayList<Tasklist> getAllTasklist(){
        DBDriver driver = DBDriver.getInstance(OrganizadorApp.getContext());
        SQLiteDatabase db = driver.getReadableDatabase();
        ArrayList<Tasklist> group = new ArrayList<>();

        String sql = "SELECT * FROM "+DBDriver.TABLE_TASKLIST;
        Cursor cursor = db.rawQuery(sql, null);

        if(cursor.moveToFirst()){
            do{
                String id = cursor.getString(  cursor.getColumnIndex(DBDriver.TASKLIST_ID)  );
                String name = cursor.getString(  cursor.getColumnIndex(DBDriver.TASKLIST_NAME)  );
                long ut = cursor.getLong(  cursor.getColumnIndex(DBDriver.TASKLIST_DATE)  );
                Date date = new Date(ut);
                Tasklist tasklist = new Tasklist(id,name,date);
                group.add(tasklist);
            }while (cursor.moveToNext());
        }

        db.close();
        return group;
    }



}
