package appmoviles.com.organizador.app;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

public class OrganizadorApp extends Application {

    private static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        OrganizadorApp.context = getApplicationContext();
    }

    public static Context getContext(){
        return context;
    }
}
