package appmoviles.com.preclase9;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import appmoviles.com.preclase9.model.data.CRUDTask;
import appmoviles.com.preclase9.model.entity.Task;
import appmoviles.com.preclase9.model.entity.Tasklist;

public class ItemsListActivity extends AppCompatActivity {

    private TextView titleTasklist;
    private Tasklist tasklist;
    private Button addTaskBtn;
    private ListView taskLV;
    private ArrayAdapter<Task> adapter;
    private ArrayList<Task> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items_list);
        titleTasklist = findViewById(R.id.title_tasklist);
        addTaskBtn = findViewById(R.id.addTaskBtn);
        taskLV = findViewById(R.id.taskLV);
        list = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        taskLV.setAdapter(adapter);


        tasklist = (Tasklist) getIntent().getExtras().getSerializable("tasklist");
        titleTasklist.setText(tasklist.getName());


        addTaskBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ItemsListActivity.this, NewTaskActivity.class);
                i.putExtra("tasklist",tasklist);
                startActivity(i);
            }
        });

        taskLV.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int pos, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ItemsListActivity.this)
                        .setTitle("Eliminar")
                        .setMessage("¿Desea eliminar la lista de tareas?")
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                        .setNeutralButton("Eliminar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                CRUDTask.deteleTask(list.get(pos));
                                refreshTasks();
                                dialogInterface.dismiss();
                            }
                        })
                        .setPositiveButton("Cambiar modificado", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                CRUDTask.toggleTaskAsComplete(list.get(pos));
                                refreshTasks();
                                dialogInterface.dismiss();
                            }
                        });
                builder.show();
                return true;
            }
        });

        taskLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l) {
                CRUDTask.toggleTaskAsComplete(list.get(pos));
                refreshTasks();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTasks();
    }

    private void refreshTasks() {
        ArrayList<Task> group = CRUDTask.getAllTaskOfTasklist(tasklist);
        list.clear();
        for(int i=0 ; i<group.size() ; i++){
            list.add(group.get(i));
        }
        adapter.notifyDataSetChanged();
    }

}
