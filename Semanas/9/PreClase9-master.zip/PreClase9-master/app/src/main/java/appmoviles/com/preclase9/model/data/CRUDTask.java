package appmoviles.com.preclase9.model.data;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Date;

import appmoviles.com.preclase9.app.OrganizadorApp;
import appmoviles.com.preclase9.model.driver.DBDriver;
import appmoviles.com.preclase9.model.entity.Task;
import appmoviles.com.preclase9.model.entity.Tasklist;

public class CRUDTask {


    public static void insertTask(Tasklist tasklist, Task task){
        DBDriver driver = DBDriver.getInstance(OrganizadorApp.getAppContext());
        SQLiteDatabase db = driver.getWritableDatabase();

        String sql = "INSERT INTO $TABLE($ID,$NAME,$DESC,$COMPLETE,$FK) VALUES('$VID','$VNAME','$VDESC',$VCOMPLETE,'$VFK')";
        sql = sql
                .replace("$TABLE", DBDriver.TABLE_TASK)
                .replace("$ID", DBDriver.TASK_ID)
                .replace("$NAME", DBDriver.TASK_NAME)
                .replace("$DESC", DBDriver.TASK_DESC)
                .replace("$COMPLETE", DBDriver.TASK_COMPLETE)
                .replace("$FK", DBDriver.FK_TASKLIST_TASK)

                .replace("$VID", task.getId())
                .replace("$VNAME", task.getName())
                .replace("$VDESC", task.getDescription())
                .replace("$VCOMPLETE", task.isComplete()?"1":"0")
                .replace("$VFK", tasklist.getId());
        db.execSQL(sql);
        db.close();
    }


    public static ArrayList<Task> getAllTaskOfTasklist(Tasklist tasklist){
        DBDriver driver = DBDriver.getInstance(OrganizadorApp.getAppContext());
        SQLiteDatabase db = driver.getReadableDatabase();
        ArrayList<Task> group = new ArrayList<>();

        String sql = "SELECT * FROM $TABLE WHERE $FID = '$VFID'";
        sql = sql
                .replace("$TABLE",DBDriver.TABLE_TASK)
                .replace("$FID",DBDriver.FK_TASKLIST_TASK)
                .replace("$VFID",tasklist.getId());
        Cursor cursor = db.rawQuery(sql, null);

        if(cursor.moveToFirst()){
            do{
                String id = cursor.getString(cursor.getColumnIndex(DBDriver.TASK_ID));
                String name = cursor.getString(cursor.getColumnIndex(DBDriver.TASK_NAME));
                String desc = cursor.getString(cursor.getColumnIndex(DBDriver.TASK_DESC));
                int completeInt = cursor.getInt(cursor.getColumnIndex(DBDriver.TASK_COMPLETE));
                Task task = new Task(id, name, desc, completeInt==1?true:false);
                group.add(task);
            }while (cursor.moveToNext());
        }

        db.close();
        return group;
    }


    public static void deteleTask(Task task) {
        DBDriver driver = DBDriver.getInstance(OrganizadorApp.getAppContext());
        SQLiteDatabase db = driver.getWritableDatabase();
        String sql = "DELETE FROM $TABLE WHERE $ID = '$FID'";
        sql = sql
                .replace("$TABLE", DBDriver.TABLE_TASK)
                .replace("$ID",DBDriver.TASK_ID)
                .replace("$FID",task.getId());
        db.execSQL(sql);
        db.close();
    }

    public static void toggleTaskAsComplete(Task task) {
        DBDriver driver = DBDriver.getInstance(OrganizadorApp.getAppContext());
        SQLiteDatabase db = driver.getWritableDatabase();
        String sql = "UPDATE $TABLE SET $COMPLETE=$VCOMPLETE WHERE $ID = '$FID'";
        sql = sql
                .replace("$TABLE", DBDriver.TABLE_TASK)
                .replace("$COMPLETE", DBDriver.TASK_COMPLETE)
                .replace("$VCOMPLETE", task.isComplete()?"0":"1")
                .replace("$ID",DBDriver.TASK_ID)
                .replace("$FID",task.getId());
        db.execSQL(sql);
        db.close();
    }
}
