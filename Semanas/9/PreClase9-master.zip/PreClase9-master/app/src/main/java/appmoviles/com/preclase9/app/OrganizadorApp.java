package appmoviles.com.preclase9.app;

import android.app.Application;
import android.content.Context;

public class OrganizadorApp extends Application {
    private static Context context;

    public void onCreate() {
        super.onCreate();
        OrganizadorApp.context = getApplicationContext();
    }

    public static Context getAppContext() {
        return OrganizadorApp.context;
    }
}
