package appmoviles.com.preclase9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.UUID;

import appmoviles.com.preclase9.model.data.CRUDTask;
import appmoviles.com.preclase9.model.entity.Task;
import appmoviles.com.preclase9.model.entity.Tasklist;

public class NewTaskActivity extends AppCompatActivity {


    private Tasklist tasklist;
    private TextView taskIdTv;
    private EditText taskNameEt;
    private EditText taskDescNameEt;
    private TextView taskFkTv;
    private Button taskCreateBTN;

    //Se generan desde el principio
    private String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_task);
        tasklist = (Tasklist) getIntent().getExtras().getSerializable("tasklist");


        taskIdTv = findViewById(R.id.taskIdTv);
        taskNameEt= findViewById(R.id.taskNameEt);
        taskDescNameEt= findViewById(R.id.taskDescNameEt);
        taskFkTv= findViewById(R.id.taskFkTv);
        taskCreateBTN = findViewById(R.id.taskCreateBTN);

        id = UUID.randomUUID().toString();
        taskIdTv.setText("ID: "+id);
        taskFkTv.setText("La tarea será agregada a la lista llamada "+tasklist.getName());


        taskCreateBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Task task = new Task(id, taskNameEt.getText().toString(), taskDescNameEt.getText().toString(), false);
                CRUDTask.insertTask(tasklist, task);
                finish();
            }
        });

    }
}
