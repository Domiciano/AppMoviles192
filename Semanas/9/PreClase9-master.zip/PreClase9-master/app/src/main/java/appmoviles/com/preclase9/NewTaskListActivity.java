package appmoviles.com.preclase9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import appmoviles.com.preclase9.model.data.CRUDTasklist;
import appmoviles.com.preclase9.model.entity.Tasklist;

public class NewTaskListActivity extends AppCompatActivity {

    private TextView tasklistIdTv;
    private EditText tasklistNameEt;
    private TextView tasklistDateTv;
    private Button tasklistCreateBTN;

    //Se generan cuando se inicia la actividad
    private String id;
    private Date date;
    private SimpleDateFormat sdf;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_task_list);

        tasklistIdTv = findViewById(R.id.tasklistIdTv);
        tasklistNameEt = findViewById(R.id.tasklistNameEt);
        tasklistDateTv = findViewById(R.id.tasklistDateTv);
        tasklistCreateBTN = findViewById(R.id.tasklistCreateBTN);
        sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        id = UUID.randomUUID().toString();
        date = Calendar.getInstance().getTime();

        tasklistIdTv.setText("ID: "+id);
        tasklistDateTv.setText("Date: "+sdf.format(date));

        tasklistCreateBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Tasklist tasklist = new Tasklist(id, tasklistNameEt.getText().toString(),date);
                CRUDTasklist.insertTasklist(tasklist);
                finish();
            }
        });
    }
}
